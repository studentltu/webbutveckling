-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Värd: 127.0.0.1
-- Tid vid skapande: 23 aug 2021 kl 18:50
-- Serverversion: 10.4.20-MariaDB
-- PHP-version: 8.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Databas: `user`
--

-- --------------------------------------------------------

--
-- Tabellstruktur `image`
--

CREATE TABLE `image` (
  `id` int(11) NOT NULL,
  `filename` varchar(255) CHARACTER SET latin1 NOT NULL,
  `description` text CHARACTER SET latin1 NOT NULL,
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `postId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumpning av Data i tabell `image`
--

INSERT INTO `image` (`id`, `filename`, `description`, `created`, `postId`) VALUES
(76, 'regression.jpg', 'map', '2021-08-22 15:04:09', 38);

-- --------------------------------------------------------

--
-- Tabellstruktur `post`
--

CREATE TABLE `post` (
  `id` int(11) NOT NULL,
  `title` varchar(255) CHARACTER SET latin1 NOT NULL,
  `content` text CHARACTER SET latin1 NOT NULL,
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `userId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumpning av Data i tabell `post`
--

INSERT INTO `post` (`id`, `title`, `content`, `created`, `userId`) VALUES
(65, 'user1 söndag', 'inlägg nr 1', '2021-08-22 15:03:23', 38),
(66, 'user3 måndag', 'inlägg nr 2', '2021-08-23 18:42:18', 40),
(67, 'user5 måndag', 'inlägg nr 3', '2021-08-23 18:43:00', 42);

-- --------------------------------------------------------

--
-- Tabellstruktur `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `username` varchar(255) CHARACTER SET latin1 NOT NULL,
  `password` varchar(255) CHARACTER SET latin1 NOT NULL,
  `title` varchar(255) CHARACTER SET latin1 NOT NULL,
  `presentation` text CHARACTER SET latin1 NOT NULL,
  `image` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumpning av Data i tabell `user`
--

INSERT INTO `user` (`id`, `user_id`, `username`, `password`, `title`, `presentation`, `image`, `created`) VALUES
(38, 0, 'user1', 'a3cb7981ad9e8059f1abdd2d21b9c6748750eb08fc1b2a79b189d0a9a9da81872711e80459f8dacd56d7aed154908d9dca368d563d7c2b1ca21b60605c556ca7', 'blog1', 'Describe your blog...', NULL, '2021-08-22 15:02:36'),
(39, 0, 'user2', '89c228d18fde6e27bf1ec3b99f3d6688c393d4a904cb3fb943eb955068baaf5e995b4c80c07c8ccaada3f6524bd063f89c20917e3be72a6cb2b3bea65733901a', 'blog2', 'Describe your blog...', NULL, '2021-08-22 15:22:34'),
(40, 0, 'user3', '3b18b815df3cfd732d45fffefc726164fcbd406e5ac9baa012cb82ca19033658f4d8d1f48b7415839810dd6d438b887979f188fb01f022a3ab7f6c247b8707c4', 'blog3', 'beskrivning blog3', NULL, '2021-08-22 16:10:19'),
(41, 0, 'user4', 'd80166d79f1e6c687a694acff13bf536f73ce6c4823728065fb8497cdb7159232476c287f66a8efe320234b5dc973cf8347cd3db37215a977ed36f9c0aaa3034', 'blog4', 'test', NULL, '2021-08-22 16:12:32'),
(42, 0, 'user5', 'f171b5e408af15527097d2858fb437f3d0ead4e5f0fa9289294074ec17367a9be5caae2be6be0982f11ee310b8cf1c598d5ccf9c4b7e92d6b28a43a67b159236', 'blog5', 'test', NULL, '2021-08-22 16:15:53');

--
-- Index för dumpade tabeller
--

--
-- Index för tabell `image`
--
ALTER TABLE `image`
  ADD PRIMARY KEY (`id`);

--
-- Index för tabell `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`id`);

--
-- Index för tabell `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD KEY `created` (`created`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `username` (`username`);

--
-- AUTO_INCREMENT för dumpade tabeller
--

--
-- AUTO_INCREMENT för tabell `image`
--
ALTER TABLE `image`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=77;

--
-- AUTO_INCREMENT för tabell `post`
--
ALTER TABLE `post`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=68;

--
-- AUTO_INCREMENT för tabell `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
