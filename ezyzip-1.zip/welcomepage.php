<?php 
//Kopplar upp mot databasen
include_once("db_credentials.php");  
include_once("db.php");   
?>
<DOCTYPE! html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title>Welcome page</title>
	<link rel="stylesheet" href="styleWelcomepage.css">
</head>
<body>
<div class="wrapper">
	

	<header class="header">
	<!-- knapp inlogg -->
	<div class="form">
			<h1>Uppgift 4</h1>
			<form action="login4.php" method="post">          
			<button type="submit" name="login" id="login" style ="float:right";>LogIn</button><br><br>  
            </form>
        </div>

    </header>
	<!-- listar användare -->
    <div class = "meny" style='color:white'>
		<h1>Latest members</h1>
		<?php 
		$result = mysqli_query($db, "SELECT * FROM user ORDER BY id DESC LIMIT 0 , 6");
		if($result) {
		while($row=mysqli_fetch_array($result)){
		echo $row['username'];
		echo "<br><br>";
			}
		};
		?>
		<!-- listar klickbar lista med användare -->
		<h1>Read members</h1>
		<?php
		$result = mysqli_query($db,"SELECT id, username, title FROM user");
		while ($row = mysqli_fetch_array($result)){

        $id = $row['id']; // Hämtar bloggarens id
        $username = substr($row['username'],0,15); // Hämtar titel på bloggen, max 30 tecken ska visas
		$title = substr($row['title'],0,15);
		
        echo "<a href='view.php?id=$id'>$username - $title</a><br>"; // Skriver ut länken 
		echo "<br>";
};
		?>
    </div>
    <div class ="content">
	<!-- Signup formulär -->
	<div class="form">
            <h1>Signup</h1>
			<form enctype="multipart/form-data" action ="myDatabaseFile.php" method="post">
            <input type="text" name="name" id="name" placeholder="name" required><br><br> 
			<input type="text" name="blog_title" id="blog_title" placeholder="blog title" required><br><br>
			<textarea rows="10" col="20" name="description">Describe your blog...</textarea><br><br><br>
            <input type="password" name="password" id="password" placeholder="password" minlength="6" required><br><br>           
			<button type="submit" name="signup" id="signup">Signup</button><br><br>  
            </form>
        </div>	
	</div>
    <div class="info" style='color:white'>
		<!-- listar alla 3 senaste inlägg -->
		<h1>Latest Post</h1>
        <?php 
		$result = mysqli_query($db, "SELECT * FROM post ORDER BY id DESC LIMIT 0 , 3");
		
		if($result) {
		while($row=mysqli_fetch_array($result)){
		
		echo $row['created']."<br><br>";
		echo "<b><u>".$row['title']."</b></u><br><br>";
		echo $row['content']."<br><br>";
		
		$id = $row['userId']."<br><br>";
		
		$sql = "SELECT username FROM user WHERE id = '$id' LIMIT 0,3";
		$result2 = mysqli_query($db,$sql);
		if($result2){
			while($row = mysqli_fetch_array($result2)){
				echo '<em>'.'posted by: '.'</em>';
				echo $row['username']; 
			}
		}

		echo '<hr id="fancyLine2">'."<br><br>";		
			}
		};
		?>
    </div>
    <footer class ="footer">
        <h1>My footer</h1>
		<p style="float:right">&copy; 2021. All Rights Reserved.</p>
    </footer>
</div>
</body>
</html>