<?php
session_start();
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="style.css">
</head>
    <body>
        <div class="form">
            <h1>Login</h1>
			<form action="login4.php" method="post">  
			<label style="color:white">User created!</label><br><br>
			<button type="submit" name="backtologin" id="backtologin">Back to login</button><br><br>
            </form>
        </div>
</body>
</html>