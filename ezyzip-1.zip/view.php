<?php
include_once("db_credentials.php");
include_once("db.php");
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<meta charset="UTF-8">
<title>View page</title>
<link rel="stylesheet" href="styleView.css">
<body>
<div class="wrapper">

<header class="header">
<!-- Knapp länkar tillbaka till förstasidan -->
<div class="form">
			<form action="welcomepage.php" method="post">          
			<button type="submit" name="back" id="back" style ="float:right";>Back to homepage</button><br><br>  
            </form>
        </div>
<?php

$id = filter_var($_GET['id'],FILTER_SANITIZE_STRING); //Kontrollerar att $_GET[] är av datatypen sträng och att den inte innehåller olovliga tecken.

$pageName = mysqli_query($db,"SELECT username FROM user WHERE id = '$id'");
while($row = mysqli_fetch_array($pageName)){
	$titlename = $row['username'];
}

echo "<h1>$titlename -page</h1>";
?>
</header>

<div class="meny">

<h1>Read members</h1>
		<?php
		$result = mysqli_query($db,"SELECT id, username, title FROM user");
		while ($row = mysqli_fetch_array($result)){

        $id = $row['id']; // Hämtar bloggarens id
        $username = substr($row['username'],0,15); // Hämtar titel på bloggen, max 30 tecken ska visas
		$title = substr($row['title'],0,15);
		
        echo "<a href='view.php?id=$id'>$username - $title</a><br>"; // Skriver ut länken 
		echo "<br>";
};
		?>
</div>
<div class="content">
<h1 style="color:black">Post</h1>
<?php
$id = filter_var($_GET['id'],FILTER_SANITIZE_STRING);
$result = mysqli_query($db,"SELECT title, content FROM post WHERE userId='$id'");

while($row = mysqli_fetch_array($result)){
	$title = $row['title'];
	$title = strtoupper($title);//Konverterar strängen till versaler.
	echo "<b>$title</b><br><br>";
	$content = $row['content'];
	echo $content."<br><br>";
	echo "<hr>";
	
}
?>

<h1 style="color:black">Photo album</h1>
		
		<?php
			
			$result = mysqli_query($db,"SELECT * FROM image WHERE postId ='$id'");
		
			if($result){
			while($row = mysqli_fetch_array($result)){
				$image = $row['filename'];
				$description = $row['description'];
				echo "<br>";
				?>
				
				<img src ="uploads\<?php echo $image ?>" height="500px" width="500px"/>;
				<?php
				echo "<br>";
				echo $description;
			}
		}
	
		?>
</div>
<div class="info">

<?php

$id = filter_var($_GET['id'],FILTER_SANITIZE_STRING);
 
$res = mysqli_query($db,"SELECT title, presentation FROM user WHERE id = '$id'");
while($row = mysqli_fetch_array($res)){
	$title = substr($row['title'],0,15); //Begränsar utskriften till 15 tecken.
	$title = strtoupper($title);
	echo $title ."<br><br>";
	$presentation = $row['presentation'];
	echo $presentation;
}
?>
</div>

<footer class ="footer">
        <h1>My footer</h1>
		<p style="float:right">&copy; 2021. All Rights Reserved.</p>
    </footer>
</div>
