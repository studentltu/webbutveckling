<?php
session_start();
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="style.css">
</head>
    <body>
        <div class="form">
		<!-- Login formulär -->
            <h1>Login</h1>
			<form action="myDatabaseFile.php" method="post">
            <input type="text" name="name" id="name" placeholder="name" required><br><br>                           
            <input type="password" name="password" id="password" placeholder="password" minlength="6" required><br><br>           
			<button type="submit" name="login" id="login">Login</button><br><br>  
			<a href="welcomepage.php">Back to homepage</a>
			
		<!-- printar ut felmeddelande om superglobal $_REQUEST[] är tom -->
			<?php		
		if( !empty( $_REQUEST['Message'] ) )
		{
		echo "<br><br>".$_REQUEST['Message'];
		}	
		?>
            </form>
        </div>
</body>
</html>
