<?php
//Denna sida registrerar nya användare till databasen:
session_start();
include_once('db_credentials.php');

//funktion som sanerar indata.
function sanitate ($input){
	 $input = filter_var($input,FILTER_SANITIZE_STRING); //validerar indata. Kontrollerar att datatypen är rätt. 
	 $input = htmlspecialchars($input,ENT_QUOTES,'UTF-8'); //Förhindrar SQL injections. Escapar specialtecken.  
	 $input = trim($input); //Plockar bort ev blanksteg.
	 return $input;
};

if(isset($_POST['signup']))
{	 
	 $name = mysqli_real_escape_string($db,$_POST['name']);
	 $name = sanitate($name);
	 
	 $blog_title = mysqli_real_escape_string($db,$_POST['blog_title']);
	 $blog_title = sanitate($blog_title);
	 
	 $password = mysqli_real_escape_string($db,$_POST['password']);
	 $password = sanitate($password);
	 
	 $description = mysqli_real_escape_string($db,$_POST['description']);
	 $description = sanitate($description);
	 
	 //Hashar lösenordet utifrån sha512 mall
	 $password_hash = hash('sha512',$password);
	 
	 $sql = mysqli_query($db,"SELECT * FROM user WHERE username = '$name'");
	 $counter = mysqli_num_rows($sql); //räknar antalet rows i usertabellen med username = $name.
	 
	 //Om antalet använder med username = $name är 0 skapas en ny användare.
	 if($counter == 0) {
	 $sql = "INSERT INTO user (username,password,title,presentation)
	 VALUES ('$name','$password_hash','$blog_title','$description')";
	 if (mysqli_query($db, $sql)) {
		header("Location:registered.php"); //länkas till en bekräftelse sida att registrering slutförts.
	 } else {
		echo "Error: " . $sql . " " . mysqli_error($db); //felmeddelande.
	 }
	 mysqli_close($db); //Stänger uppkopplingen mot databasen.
	 } else 
		header("Location:welcomepage.php");
}

// Kollar att login uppgifter stämmer. Användare och lösenord.
if(isset($_POST['login'])){
			
			$username = mysqli_real_escape_string($db,$_POST['name']);
			$username = sanitate($username); // sanerar indata med funktion.
			
			$password = mysqli_real_escape_string($db,$_POST['password']);
			$password = sanitate($password);
			
			$_SESSION['name'] = $_POST['name'];
			
			//Hashar lösenordet. Hashen blir alltid densamma för varje enskilt ord.
			$password_hash = hash('sha512',$password);
			// om användarnamn eller lösenord saknas länkas användare tillbaka till loginpage med felmeddelande i URL som printas ut i loginpage.  
			if(!empty($username)&&!empty('$password')){
				$query = "SELECT id FROM `user` WHERE username = '$username' AND password = '$password_hash'";
				if($query_run = mysqli_query($db,$query)){
					$query_num_rows = mysqli_num_rows($query_run);
					if($query_num_rows == 0){
						//Felmeddelande.
						$Message='Username or password is wrong.';
						//länk till loginpage med variabel inkluderat i URL.
						header("Location:login4.php?Message={$Message}");
					}else 
						header("Location:backendPage.php");
				} else
					echo 'query not working';
			} 
	}
	// logga ut. Sessionen förstörs.
	if (isset($_POST['logout'])){
		session_unset();
		session_destroy();
		header('location:welcomepage.php');
	}
	
// Användaren postar nytt inlägg. 
if(isset($_POST['newPost'])){
		$title = mysqli_real_escape_string($db,$_POST['title']);
		$title = sanitate($title);
		
		$content = mysqli_real_escape_string($db,$_POST['content']);
		$content = sanitate($content);
		
		$_names = $_SESSION['name'];
		
		$result =mysqli_query($db,"SELECT id FROM user WHERE username='$_names'");
		while($row =mysqli_fetch_assoc($result)){
		$userId = $row['id'];
		
		// File upload knappen. $_FILES[] tar två parametrar, filnamnet och indexnamn ur en fördefinierad array.
		if(isset($_FILES['img'])){
		 $name = $_FILES['img']['name'];
		 $size = $_FILES['img']['size'];
		 $tmp_name = $_FILES['img']['tmp_name'];
		 $error = $_FILES['img']['error'];
		 
		 $description = $_POST['description'];
		 $name = $_SESSION['name'];
		 
		 //hämtar primärnyckel från usertabellen.
		 $result = mysqli_query($db ,"SELECT id FROM user WHERE username = '$name'");
		 if($result){
			 while($row = mysqli_fetch_array($result)){
				 $id = $row['id'];
			 }
		 }
		 
		$upload_dir = "C:\\xampp\\htdocs\\uploads\\";
		$target_file = basename($_FILES['img']['name']); // tmp_name -> name
		
		if(move_uploaded_file($tmp_name, $upload_dir . $target_file)) 
		{
		mysqli_query($db,"INSERT INTO user.image (filename, description, postId) VALUES ('$target_file','$description','$id')");
		echo "Filen har laddats upp.";
		} 
		else 
		{
		echo "Ett fel uppstod...";
		}
		}
}

$sql = "INSERT INTO post (title,content,userId) VALUES ('$title','$content','$userId')";
	mysqli_query($db,$sql);
	header("Location:backendPage.php");
	exit();	
	};

//Raderaa inlägg som användaren själv skrivit.
if(isset($_POST['delete'])){
		 
	 $name = $_SESSION['name'];
	 $sql = mysqli_query($db,"SELECT id FROM user WHERE username = '$name'");
	 
	 $postId = mysqli_real_escape_string($db,$_POST['postId']);
	 $postId = sanitate($postId);
	 	 
	 if($sql){
		while($row = mysqli_fetch_array($sql)){
		 $id = $row['id'];
		}; 
	 } else 
		 echo 'database disconnnect';
	
	$postId = mysqli_real_escape_string($db,$_POST['postId']);
	$postId = sanitate($postId);
	
	$sql2 = mysqli_query($db,"SELECT id FROM post WHERE userId = '$id'");
	
	while($row = mysqli_fetch_array($sql2)){
		//Om det är inloggad användare som skrivit inlägget tas det bort.
		if($row['id'] = $id){
			$sql3 = mysqli_query($db,"DELETE post FROM post WHERE post.id = '$postId'");
			header("location:backendPage.php");
		} else 
			echo 'You can only delete your own post!';		
		}	
	 };
?>