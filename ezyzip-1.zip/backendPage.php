<?php
include("myDatabaseFile.php");
?>

<!DOCTYPE>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Index</title>
		<link rel="stylesheet" href="styleBackendpage.css">
		
	</head>
	<body>
		<div class="wrapper">
    <header class="header">
	<div class="form">
	<h1>Uppgift 4</h1>
			<!-- Logga ut -->
			<form action = "myDatabaseFile.php" method="post">          
			<button type="submit" name="logout" id="logout" style ="float:right";>Logout</button><br><br>  
            </form>
        </div>
    </header>
    
		<div class = "meny" style='color:white'>
		<h1>Latest members</h1>
		<!-- listar sidan 6 senaste användare från nyast. -->
		<?php 
		$result = mysqli_query($db, "SELECT * FROM user ORDER BY id DESC LIMIT 0 , 6");
		if($result) {
		while($row=mysqli_fetch_array($result)){
		echo $row['username'];
		echo '<hr>'."<br><br>";
			}
		};
		?>		
		<h1>Read members</h1>
		<!-- listar sidans användare -->
		<?php
		$result = mysqli_query($db,"SELECT id, username, title FROM user");
		while ($row = mysqli_fetch_array($result)){

        $id = $row['id']; // Hämtar bloggarens id
        $username = substr($row['username'],0,15); // Hämtar titel på bloggen, max 30 tecken ska visas
		$title = substr($row['title'],0,15);
		
        echo "<a href='view.php?id=$id'>$username - $title</a><br>"; // Skriver ut länken 
		echo "<br>";
};
	?>
    </div>
    
    <div class ="content">
	
	<h1 style="color:black">Create a new post</h1>
		<div class="form">
			<!-- CREATE NEW POST -->
			<form action="myDatabaseFile.php" method="post" enctype="multipart/form-data">
			<input type ="text" name="title" placeholder="post title"></input><br><br>
			<textarea name="content"></textarea><br><br>			
			<button type="submit" name="newPost" id="newPost">Add post</button><br><br>  
			</form>
			<hr>
			<h1 style="color:black">Edit post</h1>
			
			<!-- EDIT POST -->
			<!--Visa alla uppladdade bilder, redigera och ta bort bilder (med redigera menas att ändra i eventuell bildtext-->
			<form action="" method="POST">
			<input type="text" id="postId" name="postId" placeholder="# nr"></input>
			<button type="submit" id="getText" name="getText">get</button><br><br>
		<?php	
			//Hämtar valt inlägg användaren vill redigera
			if(isset($_POST['getText'])){

			$postId = $_POST['postId'];
			$_SESSION['postId'] = $postId;
	 
			$sqlGET = mysqli_query($db,"SELECT content FROM post WHERE id = '$postId'");
	 
			if($sqlGET){
			while($row = mysqli_fetch_array($sqlGET)){
			$content = $row['content'];	
			};
			?>			
			
			<textarea name="content" id="content"><?php echo $content; ?></textarea>
			<button type="submit" id="edit" name="edit"> edit </button>
			
			<?php
			}
		};
		//Edit knappen
		if(isset($_POST['edit'])){
			$postId = $_SESSION['postId'];
			$content2 = $_REQUEST['content'];
		
		$idCheck = mysqli_query($db,"SELECT userId FROM post WHERE id = '$postId'"); 
		if($idCheck){
			while($row = mysqli_fetch_array($idCheck)){
				$key = $row['userId'];
			}
		};
		//$key = user id från posttabellen.
		$userId = $_SESSION['name'];
		
		$sql = mysqli_query($db,"SELECT id FROM user WHERE username = '$userId'");
		
		while($row = mysqli_fetch_array($sql)){
			$userKey = $row['id'];
		}
		
		/* $userKey ID PÅ INLOGGAD PERSON
		   $key ID PÅ PERSON SOM SKRIVIT INLÄGG
		   Är dessa lika kan inlägget ändras.
		*/
		
		if($userKey==$key){
			
			$sql2 = mysqli_query($db,"UPDATE post SET content = '$content2' WHERE id = '$postId'");
					
						echo 'table updated';
					
				} else 
					echo 'you can only edit your own posts.';
		};
			?>
			</form>
			
			<!--EDIT POST SLUT -->
			
			<!-- RADERA POST -->
			<form action="myDatabaseFile.php" method="POST">
			<input type="text" id="postId" name="postId" placeholder="# nr"></button>
			<button type="submit" id="delete" name="delete">delete</button>
			</form>
        </div>
		
        <h1 style="color:black">Your latest post</h1>
		<!-- Inloggad användares senaste inlägg -->
		<?php 

		$_username = $_SESSION['name'];
		$sql = "SELECT id FROM user WHERE username = '$_username'";
		$userId = mysqli_query($db, $sql);
		if($userId) {
		while($row=mysqli_fetch_array($userId)){
		
		$identifier = $row['id'];
		
		$result=mysqli_query($db,"SELECT * FROM post WHERE userId = '$identifier' ORDER BY id DESC");
		if($result){
		//Printa ut data om index, författare, när inlägget är skriver, titel och innehåll.
		while($row=mysqli_fetch_array($result)){
		echo "#".$row['id']." ";
		echo "<em>".$_username." - ".$row['created']."</em>"."<br><br>";
		echo "<b><u>".$row['title']."</b></u><br><br>";
		echo $row['content']."<br><br>";
		echo '<hr>'."<br><br>";
			}	
		}
	};
};	
		?>
		
		<h1 style="color:black">Your Photo Album</h1>
		
		<a href="updateAlbum.php">Update Your album</a><br><br>
		
		<form method="POST" action="" enctype="multipart/form-data">
		<input type="text" id ="deleteImgIndex" name="deleteImgIndex"></input><br><br>
		<input type="submit" id="deleteIMG" name="deleteIMG" value="delete"></input><br><br>
		</form>
		
		<?php
		
		// Endast användare kan radera sina egna bilder.
			if(isset($_POST['deleteIMG'])){
			
			$deleteImgIndex = $_POST['deleteImgIndex'];
			mysqli_query($db,"DELETE FROM image WHERE id = '$deleteImgIndex'");
		}
		
			// Printar ut bild.
			
			$result = mysqli_query($db,"SELECT * FROM image WHERE postId ='$identifier' ORDER BY id DESC");
		
			if($result){
			while($row = mysqli_fetch_array($result)){
				$image = $row['filename'];
				$id = $row['id'];
				$description = $row['description'];
				echo "<br>";
				echo "#".$id." ";
				?>
				
				<img src ="uploads\<?php echo $image ?>" height="500px" width="500px"/>;
				<?php
				echo "<br>";
				echo $description;
			}
		}
	?>	
	
    </div>
	
	<div class="info" style='color:white'>
		<h1>Latest Post</h1>
        <?php 
		//Senaste 3 inläggen printas.
		$result = mysqli_query($db, "SELECT * FROM post ORDER BY id DESC LIMIT 0 , 3");
		
		if($result) {
		while($row=mysqli_fetch_array($result)){
		
		echo "#".$row['id']." ";
		
		$id = $row['userId']."<br><br>";
		
		$sql = "SELECT username FROM user WHERE id = '$identifier' LIMIT 0,3";
		$result2 = mysqli_query($db,$sql);
		if($result2){
			while($row2 = mysqli_fetch_array($result2)){
				echo '<em>'.'posted by: '.'</em>';
				echo $row2['username']; 
				echo "<br><br>";
			}
		}
		echo "<b><u>".$row['title']."</b></u><br><br>";
		echo $row['content']."<br><br>";
		echo $row['created']."<br><br>";
		echo '<hr>'."<br><br>";		
			}
		};
		
		?>
    </div>
    <footer class ="footer">
        <h1>My footer</h1>
    </footer>
</div>
	</body>
</html>