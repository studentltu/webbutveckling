<?php
	include_once("db.php");

	//lokal databas
	
/*
	$conerror = 'could not connect';
	define("DB_SERVER", "localhost");
    define("DB_USER",   "root");
    define("DB_PASS",   "");
    define("DB_NAME",   "user");
*/
	//utbweb.its.ltu.se:3308
	//utbweb.its.ltu.se/~andfra-9/Webbutveckling%20II/uppgift4/
	$conerror = 'could not connect';
	/*
	define("DB_SERVER", "utbweb.its.ltu.se:3308");
    define("DB_USER",   "andfra9");
    define("DB_PASS",   "sn8rRkjx");
    define("DB_NAME",   "D0019E_V21_andfra9");
*/
$db = db_connect();

//db_disconnect($db);

//TEST
$filename = "user.sql";
db_import($db, $filename, $dropOldTables=TRUE);

//SLUT
?>