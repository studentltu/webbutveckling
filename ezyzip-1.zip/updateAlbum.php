<?php
include_once("db_credentials.php");   
session_start();
?>

<!DOCTYPE html>
<html>
<head>
<title>Update yor album</title>
<link rel="stylesheet" href="style.css">
</head>

<body>
<!-- Uppdatera fotoalbum med nya bilder. -->
<div class="form">

	<h3><a href="backendPage.php">BACK TO LOGIN PAGE</a></h3><br>
	<form method="POST" action="" enctype="multipart/form-data">
	<input type="hidden" name="MAX_FILE_SIZE" value="1000000" />
	<input type="file" id="img" name="img"></input><br><br>
	<input type="text" id="description" name="description" placeholder="Image description"></input><br><br>
	<input type="submit" id="send" name="send" value="upload"></input>
	</form>
	
	<!-- Ändra bildbeskrivning -->
	<h3 style="color:white">EDIT IMAGE DESCRIPTION</h3>
	
			<form action="" method="POST">
			<input type="text" id="imgpostId" name="imgpostId" placeholder="# nr"></input>
			<button type="submit" id="imggetText" name="imggetText">get</button><br><br>
		<?php	
		
			if(isset($_POST['imggetText'])){

			$imgpostId = $_POST['imgpostId'];
			$_SESSION['imgpostId'] = $imgpostId; //placerar imgpostId i en superglobal variabel för att göra den tillgänglig i if sats längre ner.
	 
			$sqlGET = mysqli_query($conn,"SELECT description FROM image WHERE id = '$imgpostId'");
	 
			if($sqlGET){
			while($row = mysqli_fetch_array($sqlGET)){
			$description = $row['description'];	
			};
			?>			
			<!-- printar ut bildbeskrivning från valt inlägg -->
			<textarea name="imgcontent" id="imgcontent"><?php echo $description; ?></textarea>
			<button type="submit" id="imgedit" name="imgedit"> edit </button>
			
			<?php
			}
		};
		//Ändrar texten i den hämtade bildbeskrivningen om knappen imgedit aktiveras.
		if(isset($_POST['imgedit'])){
			$description2 = $_POST['imgcontent'];
			
			$userId = $_SESSION['name'];
		
		$sql = mysqli_query($conn,"SELECT id FROM user WHERE username = '$userId'");
		
		while($row = mysqli_fetch_array($sql)){
			$userKey = $row['id'];
		}
		
		$idCheck = mysqli_query($conn,"SELECT * FROM image WHERE postId = '$userKey'"); 
		if($idCheck){
			while($row = mysqli_fetch_array($idCheck)){
				$key = $row['postId'];
			}
		};
		//Om inloggad inloggad användare är kopplad till skapat inlägg:
		if($userKey==$key){
			$imgpostId = $_SESSION['imgpostId'];
			
			mysqli_query($conn,"UPDATE image SET description = '$description2' WHERE id = $imgpostId");
					
						echo 'table updated'; //inlägget uppdaterat.
					
				} else 
					echo 'you can only edit your own posts.'; //Inlägget är inte kopplat till inloggad användare.
		};
			?>
			</form>
	
		<?php
		
		 if((isset($_POST['send'])) && (isset($_FILES['img']))){
		 echo "<pre>";
		 print_r($_FILES['img']); //Printar ut metadata om bilden.
		 echo "</pre>";
		 //initierar metadata till namngivna variabler.
		 $name = $_FILES['img']['name'];
		 $size = $_FILES['img']['size'];
		 $tmp_name = $_FILES['img']['tmp_name'];
		 $error = $_FILES['img']['error'];
		 
		 $description = $_POST['description'];
		 $name = $_SESSION['name'];
		 
		 $result = mysqli_query($db ,"SELECT id FROM user WHERE username = '$name'");
		 if($result){
			 while($row = mysqli_fetch_array($result)){
				 $id = $row['id'];
			 }
		 }
		 
		$upload_dir = "C:\\xampp\\htdocs\\uploads\\"; //Filens målmapp.
		$target_file = basename($_FILES['img']['name']); //Användarens valda filnamn.
		//Placerar filen i målmappen. Ändrar filens temporära namn till användarens valda.
		if(move_uploaded_file($tmp_name, $upload_dir . $target_file))
		{
		mysqli_query($conn,"INSERT INTO user.image (filename, description, postId) VALUES ('$target_file','$description','$id')");
		echo "Filen har laddats upp.";
		} 
		else 
		{
		echo "Ett fel uppstod...";
		}
	};
			//Listar alla bilder med index och beskrivning.
			$result = mysqli_query($db,"SELECT * FROM image");
		
			if($result){
			while($row = mysqli_fetch_array($result)){
				$image = $row['filename'];
				$description = $row['description'];
				$id = $row['id'];
				echo $id." ".$image;
				echo "<br>";
				echo $description;
				echo "<br>";
				?>
				<!-- Printar ut bilder. -->
				<img src ="uploads\<?php echo $image ?>" height="250px" width="250px"/>;
				<?php
				echo "<br><br>";
			}
		}
	
		?>
	</div>
</body>

</html>